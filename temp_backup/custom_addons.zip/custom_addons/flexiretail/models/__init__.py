# -*- coding: utf-8 -*-
#################################################################################
# Author      : Acespritech Solutions Pvt. Ltd. (<www.acespritech.com>)
# Copyright(c): 2012-Present Acespritech Solutions Pvt. Ltd.
# All Rights Reserved.
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#################################################################################

import account
import loyalty
import cross_selling
import cash_points
import product
import hr
import pos
import res_config
# import product
import stock
import dynamic_product_page_report
import dynamic_product_small_label_report_template
import sales_details_pdf_template
import res_users
# import pos_coupon
import res_company
# import bonus_return
import res_partner
import wallet_management
import pos_mirror_image
import aspl_voucher
import gift_card
import sale
import pos_order_report

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
