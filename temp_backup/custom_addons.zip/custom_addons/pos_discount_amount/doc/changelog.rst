================================================
``pos_discount_amount`` changelog
================================================

*****

Fixed an issue for fixed amount

*****

Fixed an issue for fixed amount.

