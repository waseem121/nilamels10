How to use this module?
==============

If this module is installed then "Product vendors" field hidden for all users. Select "Show product vendors" group on user settings to show vendors to specific users.

If you have any questions then you can contact us via following email. Support email: almas@dusal.net

.. image:: https://dusal.net/other/odoo/dusal_hide_vendor/screenshot.png

.. image:: https://dusal.net/other/odoo/dusal_hide_vendor/screenshot0.png

.. image:: https://dusal.net/other/odoo/dusal_hide_vendor/screenshot1.png


Change log
==============

Version 1.0: First version
