# -*- coding: utf-8 -*-
##############################################################################
#
#    Addon for Odoo sale by Dusal.net
#    Copyright (C) 2015 Dusal.net Almas
#
##############################################################################


#import logging

#from openerp import SUPERUSER_ID
#from openerp import tools
##from openerp.modules.module import get_module_resource
#from openerp import fields, osv
##from openerp.tools.translate import _
##from datetime import datetime
#from openerp import models

#class product_product(osv.osv):
    #_inherit = "product.product"
    
#class product_template(osv.osv):
    #_inherit = "product.template"
    
    #_columns = {

    #}
    #_defaults = {
                    
                #}
