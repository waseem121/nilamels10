How to use this module?
==============

If this module is installed then "Cost price" is hidden for all users. Select "Show product cost price" group on user settings to show Cost price to specific users.

If you have any questions then you can contact us via following email. Support email: almas@dusal.net

.. image:: https://dusal.net/other/odoo/dusal_product/screenshot0.png

.. image:: https://dusal.net/other/odoo/dusal_product/screenshot1.png

.. image:: https://dusal.net/other/odoo/dusal_product/screenshot.png


Change log
==============

Version 2.1: XML bug fixed
Version 2.2: Added sale price option
