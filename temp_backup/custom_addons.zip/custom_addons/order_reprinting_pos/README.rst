==================
Pos Old Orders v10
==================

This module adds new options for listing the old orders and printing the corresponding receipts.

Installation
============

Just select it from available modules to install it, there is no need to extra installations.

Configuration
=============

Nothing to configure.

Credits
=======
Developer: Linto CT @ cybrosys, linto@cybrosys.in


