=====================================
Reduced Accounting Entries In POS V10
=====================================

This module allow passing a single journal entry for POS transaction.

Installation
============

Just select it from available modules to install it, there is no need to extra installations.

Configuration
=============

Nothing to configure.

Features
========

* Allows recording payments as a single entry.
* Eliminates unnecessary return entry in pos.

Credits
=======

Cybrosys Technologies, odoo@cybrosys.com


