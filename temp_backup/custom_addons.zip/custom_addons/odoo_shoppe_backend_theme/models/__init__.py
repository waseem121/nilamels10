# -*- coding: utf-8 -*-
import ir_qweb
import ir_ui_menu
import res_users_inherit