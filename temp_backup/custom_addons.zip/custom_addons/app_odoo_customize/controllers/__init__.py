# -*- coding: utf-8 -*-

from . import web_favicon
