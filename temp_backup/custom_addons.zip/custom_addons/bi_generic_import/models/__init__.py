# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.


import sale
import account_invoice
import purchase
import stock
import product
import partner
import picking

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
