# -*- coding: utf-8 -*-
from . import test_pos_analytic_by_config
